import socket
import os
import time
import argparse
import sys
import os
import platform

colors = True  # Output should be colored
machine = sys.platform  # Detecting the os of current system
checkplatform = platform.platform() # Get current version of OS
if machine.lower().startswith(('os', 'win', 'darwin', 'ios')):
    colors = False  # Colors shouldn't be displayed in mac & windows
if checkplatform.startswith("Windows-10") and int(platform.version().split(".")[2]) >= 10586:
    colors = True
    os.system('')   # Enables the ANSI
if not colors:
    end = red = white = green = yellow = run = bad = good = info = que = ''
else:
    white = '\033[97m'
    green = '\033[92m'
    red = '\033[91m'
    yellow = '\033[93m'
    end = '\033[0m'
    blue = '\033[93m'
    reset ='\033[0m'
    back = '\033[7;91m'
    info = '\033[93m[!]\033[0m'
    que = '\033[94m[?]\033[0m'
    bad = '\033[91m[-]\033[0m'
    good = '\033[92m[+]\033[0m'
    run = '\033[97m[~]\033[0m'
logo =f"""
{yellow}
  _____  _____          _   _ 
 / ____|/ ____|   /\   | \ | |
| (___ | |       /  \  |  \| |
 \___ \| |      / /\ \ | . ` |
 ____) | |____ / ____ \| |\  |
|_____/ \_____/_/    \_\_| \_|
                              
                              
{end}
{red}Version:1.7{end}
{green}By:@SMDD{end}
{yellow}usage{end}: scan.py [-h] [-t TIMEOUT] [-il FILE_IP_] [-pl FILE_] [-i IP] [-m MOD]

{yellow}optional arguments{end}:
  -h, --help            show this help message and exit
  -t TIMEOUT, --timeout TIMEOUT
                        timeout
  -il FILE_IP_, --IPFile FILE_IP_
                        IP List
  -pl FILE_, --portFile FILE_
                        Port List
  -i IP, --IP IP        IP
  -m MOD, --mod MOD     Scan
                        Mod:List/Port/None/Ploit_Port/Ploit_None/Ploit_List
"""
target = ""
file = ""
time_out = ""
file_ip = ""
ip_list=""
port_ =""
ip_list_ =""
_ip_ = ""
db =""
def main():
    print(logo)
    global host
    global time_out
    global port
    global file
    global target
    global file_ip
    parser = argparse.ArgumentParser()
    parser.add_argument('-t','--timeout', help='timeout',
                        dest='Timeout', type=int)
    parser.add_argument('-il','--IPFile', help=' IP List',
                        dest='file_ip_', type=str)
    parser.add_argument('-pl','--portFile', help='Port List',
                        dest='file_', type=str)
    parser.add_argument('-i','--IP', help=' IP',
                        dest='IP', type=str)
    parser.add_argument('-m','--mod', help='Scan Mod:List/Port/None/Ploit_Port/Ploit_None/Ploit_List',
                        dest='mod', type=str)
    args = parser.parse_args()
    time_out = args.Timeout
    file_ip = args.file_ip_
    target = args.IP
    found = args.mod
    file = args.file_
    if found =="List":
        ip_start_scan()
    elif found =="Port":
        port_start_scan()
    elif found =="None":
        start_scan()
    elif found =="Ploit_Port":
        port_db_start_scan()
    elif found =="Ploit_List":
        ip_db_start_scan()
    elif found =="Ploit_None":
        db_start_scan()
    else:
        exit()
def start_scan():
    global target
    global file
    global port_list
    try:
        port_list_open = open(file, "r", buffering=25000)
    except FileNotFoundError as FileError:
        print(f"[{yellow}-{end}]File Error Info:")
        print("FileError")
        main()
    _port_ = port_list_open.readlines()
    print(f'[{yellow}*{end}] Starting Scan')
    print(f"[{yellow}*{end}] Host:" + str(target))
    print(f"[{yellow}*{end}]Port File: " + str(file))
    for port_list in _port_:
        port_list = port_list.strip()
        scan()
def ip_start_scan():
    global ip_list
    global file_ip
    global file
    global port_list
    try:
        port_list_open = open(file, "r", buffering=25000)
        ip_list_open = open(file_ip, "r", buffering=25000)
    except FileNotFoundError as FileError:
        print(f"[{red}-{reset}]File Error Info:")
        print(FileError)
        main_ip()
    _port_ = port_list_open.readlines()
    _ip_ = ip_list_open.readlines()
    print(f'[{blue}*{reset}] Starting Scan')
    print(f"[{blue}*{reset}]Port File: " + str(file))
    print(f"[{blue}*{reset}]IP File: " + str(file_ip))
    for ip_list in _ip_:
        ip_list = ip_list.strip()
        for port_list in _port_:
            port_list = port_list.strip()
            ip_scan()
def port_start_scan():
    global ip_scan
    global file_ip
    global port_
    global port_list
    try:
        ip_list_open = open(file_ip, "r", buffering=25000)
    except FileNotFoundError as FileError:
        print(f"[{red}-{reset}]File Error Info:")
        print(FileError)
        main_2()
    _ip_ = ip_list_open.readlines()
    print(f'[{blue}*{reset}] Starting Scan')
    print(f"[{blue}*{reset}]Port: " + str(port_))
    print(f"[{blue}*{reset}]IP File: " + str(file_ip))
    for ip_list in _ip_:
        ip_list = ip_list.strip()
        port_scan()
def ip_scan():
    global port_list
    global time_out
    global ip_list
    s = socket.socket()
    try:
        s.settimeout(int(time_out))
        s.connect((ip_list, int(port_list)))
        s.close()
        print("Scan IP:"+str(ip_list))
    except TimeoutError as Timeout:
        print(f"[{red}-{reset}] Timeout Error Info:")
        print(Timeout)
        print(f"Port Close or Uknow")
    except OverflowError as Overflow:
        print(f"[{red}-{reset}]Overflow Error Info:")
        print(Overflow)
        print(f"[{blue}*{reset}]Port Error")
    except socket.timeout as time_out_socket:
        print(f"[{red}-{reset}]Time Out Info:")
        print(time_out_socket)
        print("Port:"+str(port_list))
        print("Close Or Connect Error")
    except OSError as OS_Error:
        print(f"[{red}-{reset}]OSError Unkonw ErrorInfo:")
        print(OS_Error)
        print("Port:"+str(port_list))
        print("Connect Error Port Close ")
    else:
        test_service()
def scan():
    global port_list
    global target
    global time_out
    s = socket.socket()
    try:
        s.settimeout(int(time_out))
        s.connect((target, int(port_list)))
        s.close()
    except TimeoutError as Timeout:
        print(f"[{red}-{reset}] Timeout Error Info:")
        print(Timeout)
        print(f"Port Close or Uknow")
    except OverflowError as Overflow:
        print(f"[{red}-{reset}]Overflow Error Info:")
        print(Overflow)
        print(f"[{blue}*{reset}]Port Error")
    except socket.timeout as time_out_socket:
        print(f"[{red}-{reset}]Time Out Info:")
        print(time_out_socket)
        print("Port:"+str(port_list))
        print("Close Or Connect Error")
    except OSError as OS_Error:
        print(f"[{red}-{reset}]OSError Unkonw ErrorInfo:")
        print(OS_Error)
        print("Port:"+str(port_list))
        print("Connect Error Port Close")
    else:
        test_service()
def port_scan():
    global port_
    global ip_list
    global time_out
    s = socket.socket()
    try:
        s.settimeout(int(time_out))
        s.connect((ip_list, int(port_)))
        s.close()
    except TimeoutError as Timeout:
        print(f"[{red}-{reset}] Timeout Error Info:")
        print(Timeout)
        print(f"Port Close or Uknow")
    except OverflowError as Overflow:
        print(f"[{red}-{reset}]Overflow Error Info:")
        print(Overflow)
        print(f"[{blue}*{reset}]Port Error")
    except socket.timeout as time_out_socket:
        print(f"[{red}-{reset}]Time Out Info:")
        print(time_out_socket)
        print("Port:"+str(port_))
        print("Close Or Connect Error")
    except OSError as OS_Error:
        print(f"[{red}-{reset}]OSError Unkonw ErrorInfo:")
        print(OS_Error)
        print("Port:"+str(port_))
        print("Connect Error Port Close")
    else:
        test_service()
def test_service():
    global port_list
    global target
    port_test = port_list
    if port_test == "445":
        print(f"[{green}+{reset}]Port Open 445 Service SMB")
    elif port_test == "443":
        print(f"[{green}+{reset}]Port Open 443 Service HTTPS")
    elif port_test == "8080":
        print(f"[{green}+{reset}]Port Open 8080 Service Proxy")
    elif port_test == "80":
        print(f"[{green}+{reset}]Port Open 80 Service HTTP")
    elif port_test == "21":
        print(f"[{green}+{reset}]Port Open 21 Service FTP")
    elif port_test == "53":
        print(f"[{green}+{reset}]Port Open 53 Service DNS")
    elif port_test == "1863":
        print(f"[{green}+{reset}]Port Open 1863 Service MSN")
    elif port_test == "109":
        print(f"[{green}+{reset}]Port Open 109 Service POP2")
    elif port_test == "110":
        print(f"[{green}+{reset}]Port Open 110 Service POP3")
    elif port_test == "995":
        print(f"[{green}+{reset}]Port Open 995 Service POP3S")
    elif port_test == "143":
        print(f"[{green}+{reset}]Port Open 143 Service IMAP")
    elif port_test == "993":
        print(f"[{green}+{reset}]Port Open 993 Service IMAPS")
    elif port_test == "25":
        print(f"[{green}+{reset}]Port Open 25 Service SMTP")
    elif port_test == "465":
        print(f"[{green}+{reset}]Port Open 465 Service ISA/TMG")
    elif port_test == "119":
        print(f"[{green}+{reset}]Port Open 119 Service NNTP")
    elif port_test == "563":
        print(f"[{green}+{reset}]Port Open 563 Service NNTPS")
    elif port_test == "23":
        print(f"[{green}+{reset}]Port Open 23 Service Telnet")
    elif port_test == "68":
        print(f"[{green}+{reset}]Port Open 68 Service DHCP-I")
    elif port_test == "67":
        print(f"[{green}+{reset}]Port Open 67 Service DHCP-O")
    elif port_test == "546":
        print(f"[{green}+{reset}]Port Open 546 Service DHCP-V6")
    elif port_test == "389":
        print(f"[{green}+{reset}]Port Open 389 Service LDAP")
    elif port_test == "636":
        print(f"[{green}+{reset}]Port Open 636 Service LDAPS")
    elif port_test == "3269":
        print(f"[{green}+{reset}]Port Open 3269 Service Secure lightweight directory access protocol global catalog protocol")
    elif port_test == "50389":
        print(f"[{green}+{reset}]Port Open 50389 Service Exchange Server EdgeSync")
    elif port_test == "50636":
        print(f"[{green}+{reset}]Port Open 50636 Service Exchange Server EdgeSync Secure ")
    elif port_test == "137":
        print(f"[{green}+{reset}]Port Open 137 Service NetBIOS-Name Service")
    elif port_test == "138":
        print(f"[{green}+{reset}]Port Open 138 Service NetBIOS-Data")
    elif port_test == "139":
        print(f"[{green}+{reset}]Port Open 138 Service NetBIOS-Conversation")
    elif port_test == "123":
        print(f"[{green}+{reset}]Port Open 123 Service UDP")
    elif port_test == "520":
        print(f"[{green}+{reset}]Port Open 520 Service routing information protocol")
    elif port_test == "161":
        print(f"[{green}+{reset}]Port Open 161 Service SNMP")
    elif port_test == "162":
        print(f"[{green}+{reset}]Port Open 162 Service Simple Network Management Protocol-Trap")
    elif port_test == "9988":
        print(f"[{green}+{reset}]Port Open 9988 Service Windows Communication Foundation")
    elif port_test == "5355":
        print(f"[{green}+{reset}]Port Open 5355 Service Local Connection Multicast Name Resolution")
    elif port_test == "7":
        print(f"[{green}+{reset}]Port Open 7 Service TCP/UDP")
    elif port_test == "135":
        print(f"[{green}+{reset}]Port Open 135 Service Protocol used to publish Exchange servers for RPC access from external networks")
    elif port_test == "79":
        print(f"[{green}+{reset}]Port Open 79 Service Joint program protocol ")
    elif port_test == "1494":
        print(f"[{green}+{reset}]Port Open 1494 Service Citrix intelligent console architecture protocol")
    elif port_test == "1723":
        print(f"[{green}+{reset}]Port Open 1723 Service PPTP VPN")
    elif port_test == "1701":
        print(f"[{green}+{reset}]Port Open 1701 Service L2TP VPN")
    elif port_test == "1433":
        print(f"[{green}+{reset}]Port Open 1433 Service Microsoft SQL")
    elif port_test == "1755":
        print(f"[{green}+{reset}]Port Open 1755 Service MMS")
    elif port_test == "1812":
        print(f"[{green}+{reset}]Port Open 1812 Service RADIUS")
    elif port_test == "1813":
        print(f"[{green}+{reset}]Port Open 1813 Service Remote authentication dial-up user service accounting protocol")
    elif port_test == "3389":
        print(f"[{green}+{reset}]Port Open 3389 Service RDP")
    elif port_test == "554":
        print(f"[{green}+{reset}]Port Open 554 Service RTSP")
    elif port_test == "5060":
        print(f"[{green}+{reset}]Port Open 5060 Service SIP")
    elif port_test == "5061":
        print(f"[{green}+{reset}]Port Open 5061 Service SIPS")
    elif port_test == "1080":
        print(f"[{green}+{reset}]Port Open 1080 Service SOCKS")
    elif port_test == "22":
        print(f"[{green}+{reset}]Port Open 22 Service SSH")
    elif port_test == "3544":
        print(f"[{green}+{reset}]Port Open 3544 Service Teredo")
    elif port_test == "69":
        print(f"[{green}+{reset}]Port Open 69 Service TFTP")
    elif port_test == "43":
        print(f"[{green}+{reset}]Port Open 43 Service WhoIs")
    else:
        print(f"[{blue}*{reset}]Port Unkonw" + str(port_list) + "Service Unknow")
def db_start_scan():
    global target
    global file
    global port_list
    try:
        port_list_open = open(file, "r", buffering=25000)
    except FileNotFoundError as FileError:
        print(f"[{red}-{reset}]File Error Info:")
        print(FileError)
        main()
    _port_ = port_list_open.readlines()
    print(f'[{blue}*{reset}] Starting Scan')
    print(f"[{blue}*{reset}] Host" + str(target))
    print(f"[{blue}*{reset}]Port File " + str(file))
    for port_list in _port_:
        port_list = port_list.strip()
        db_scan()
def ip_db_start_scan():
    global file_ip
    global file
    global port_list
    global ip_list
    try:
        port_list_open = open(file, "r", buffering=25000)
        ip_list_open = open(file_ip, "r", buffering=25000)
    except FileNotFoundError as FileError:
        print(f"[{red}-{reset}]File Error Info:")
        print(FileError)
        main()
    _port_ = port_list_open.readlines()
    _ip_ = ip_list_open.readlines()
    print(f'[{blue}*{reset}] Starting Scan')
    print(f"[{blue}*{reset}] IP File" + str(file_ip))
    print(f"[{blue}*{reset}]Port File " + str(file))
    for port_list in _port_:
        port_list = port_list.strip()
        for ip_list in _ip_:
            ip_list = ip_list.strip()
            ip_db_scan()
def port_db_start_scan():
    global file_ip
    global file
    global port_
    global ip_list
    global _ip_
    try:
        ip_list_open = open(file_ip, "r",buffering=25000)
    except FileNotFoundError as FileError:
        print(f"[{red}-{reset}]File Error Info:")
        print(FileError)
        main()
        _ip_ = ip_list_open.readlines()
    print(f'[{blue}*{reset}] Starting Scan')
    print(f"[{blue}*{reset}] IP File" + str(file_ip))
    print(f"[{blue}*{reset}]Port " + str(port_))
    for ip_list in _ip_:
        ip_list = ip_list.strip()
        port_db_scan()
def db_scan():
    global port_list
    global target
    global time_out
    s = socket.socket()
    try:
        s.settimeout(int(time_out))
        s.connect((target, int(port_list)))
        s.close()
    except TimeoutError as Timeout:
        print(f"[{red}-{reset}] Timeout Error Info:")
        print(Timeout)
        print(f"Port Close or Uknow")
    except OverflowError as Overflow:
        print(f"[{red}-{reset}]Overflow Error Info:")
        print(Overflow)
        print(f"[{blue}*{reset}]Port Error")
    except socket.timeout as time_out_socket:
        print(f"[{red}-{reset}]Time Out Info:")
        print(time_out_socket)
        print("Port:"+str(port_list))
        print("Close Or Connect Error")
    except OSError as OS_Error:
        print(f"[{red}-{reset}]OSError Unkonw ErrorInfo:")
        print(OS_Error)
        print("Port:"+str(port_list))
        print("Connect Error Port Close ")
    except ValueError as value:
        print("Error Info:")
        print(value)
        print("exit....")
        exit()
    else:
        db_test_service()
def port_db_scan():
    global port_
    global ip_list
    global time_out
    s = socket.socket()
    try:
        s.settimeout(int(time_out))
        s.connect((ip_list, int(port_)))
        s.close()
        print(ip_list)
    except TimeoutError as Timeout:
        print(f"[{red}-{reset}] Timeout Error Info:")
        print(Timeout)
        print(f"Port Close or Uknow")
    except OverflowError as Overflow:
        print(f"[{red}-{reset}]Overflow Error Info:")
        print(Overflow)
        print(f"[{blue}*{reset}]Port Error")
    except socket.timeout as time_out_socket:
        print(f"[{red}-{reset}]Time Out Info:")
        print(time_out_socket)
        print("Port:"+str(port_))
        print("Close Or Connect Error")
    except OSError as OS_Error:
        print(f"[{red}-{reset}]OSError Unkonw ErrorInfo:")
        print(OS_Error)
        print("Port:"+str(port_))
        print("Connect Error Port Close")
    except ValueError as value:
        print("Error Info:")
        print(value)
        print("exit....")
        exit()
    else:
        db_test_service()
def ip_db_scan():
    global port_list
    global ip_list
    global time_out
    s = socket.socket()
    try:
        s.settimeout(int(time_out))
        s.connect((ip_list, int(port_list)))
        s.close()
        print(ip_list)
    except TimeoutError as Timeout:
        print(f"[{red}-{reset}] Timeout Error Info:")
        print(Timeout)
        print(f"Port Close or Uknow")
    except OverflowError as Overflow:
        print(f"[{red}-{reset}]Overflow Error Info:")
        print(Overflow)
        print(f"[{blue}*{reset}]Port Error")
    except socket.timeout as time_out_socket:
        print(f"[{red}-{reset}]Time Out Info:")
        print(time_out_socket)
        print("Port:"+str(port_list))
        print("Close Or Connect Error")
    except OSError as OS_Error:
        print(f"[{red}-{reset}]OSError Unkonw ErrorInfo:")
        print(OS_Error)
        print("Port:"+str(port_list))
        print("Connect Error Port Close")
    except ValueError as value:
        print("Error Info:")
        print(value)
        print("exit....")
        exit()
    else:
        db_test_service()
def db_test_service():
    log()
    global port_list
    global target
    global db
    port_test = port_list
    if port_test == "445":
        print(f"[{green}+{reset}]Port Open 445 Service SMB")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "SMB" in db:
                print(db)
                f.close()
    elif port_test == "443":
        print(f"[{green}+{reset}]Port Open 443 Service HTTPS")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "HTTPS" in db:
                print(db)
                f.close()
    elif port_test == "8080":
        print(f"[{green}+{reset}]Port Open 8080 Service Proxy")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "Proxy" in db:
                print(db)
                f.close()
    elif port_test == "80":
        print(f"[{green}+{reset}]Port Open 80 Service HTTP")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "HTTP" in db:
                print(db)
                f.close()
    elif port_test == "21":
        print(f"[{green}+{reset}]Port Open 21 Service FTP")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "FTP" in db:
                print(db)
                f.close()
    elif port_test == "53":
        print(f"[{green}+{reset}]Port Open 53 Service DNS")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "DNS" in db:
                print(db)
                f.close()
    elif port_test == "1863":
        print(f"[{green}+{reset}]Port Open 1863 Service MSN")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "MSN" in db:
                print(db)
                f.close()
    elif port_test == "109":
        print(f"[{green}+{reset}]Port Open 109 Service POP2")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "POP2" in db:
                print(db)
                f.close()
    elif port_test == "110":
        print(f"[{green}+{reset}]Port Open 110 Service POP3")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "POP3" in db:
                print(db)
                f.close()
    elif port_test == "995":
        print(f"[{green}+{reset}]Port Open 995 Service POP3S")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "POP3S" in db:
                print(db)
                f.close()
    elif port_test == "143":
        print(f"[{green}+{reset}]Port Open 143 Service IMAP")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "IMAP" in db:
                print(db)
                f.close()
    elif port_test == "993":
        print(f"[{green}+{reset}]Port Open 993 Service IMAPS")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "IMAPS" in db:
                print(db)
                f.close()
    elif port_test == "25":
        print(f"[{green}+{reset}]Port Open 25 Service SMTP")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "SMTP" in db:
                print(db)
                f.close()
    elif port_test == "465":
        print(f"[{green}+{reset}]Port Open 465 Service ISA/TMG")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "ISA/TMG" in db:
                print(db)
                f.close()
    elif port_test == "119":
        print(f"[{green}+{reset}]Port Open 119 Service NNTP")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "NNTP" in db:
                print(db)
                f.close()
    elif port_test == "563":
        print(f"[{green}+{reset}]Port Open 563 Service NNTPS")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "NNTPS" in db:
                print(db)
                f.close()
    elif port_test == "23":
        print(f"[{green}+{reset}]Port Open 23 Service Telnet")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "Telnet" in db:
                print(db)
                f.close()
    elif port_test == "68":
        print(f"[{green}+{reset}]Port Open 68 Service DHCP-I")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "DHCP" in db:
                print(db)
                f.close()
    elif port_test == "67":
        print(f"[{green}+{reset}]Port Open 67 Service DHCP-O")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "DHCP" in db:
                print(db)
                f.close()
    elif port_test == "546":
        print(f"[{green}+{reset}]Port Open 546 Service DHCP-V6")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "DHCP" in db:
                print(db)
                f.close()
    elif port_test == "389":
        print(f"[{green}+{reset}]Port Open 389 Service LDAP")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "LDAP" in db:
                print(db)
                f.close()
    elif port_test == "636":
        print(f"[{green}+{reset}]Port Open 636 Service LDAPS")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "LDAPS" in db:
                print(db)
                f.close()
    elif port_test == "3269":
        print(f"[{green}+{reset}]Port Open 3269 Service Secure lightweight directory access protocol global catalog protocol")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "3269" in db:
                print(db)
                f.close()
    elif port_test == "50389":
        print(f"[{green}+{reset}]Port Open 50389 Service Exchange Server EdgeSync")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "Sync" in db:
                print(db)
                f.close()
    elif port_test == "50636":
        print(f"[{green}+{reset}]Port Open 50636 Service Exchange Server EdgeSync Secure ")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "Sync" in db:
                print(db)
                f.close()
    elif port_test == "137":
        print(f"[{green}+{reset}]Port Open 137 Service NetBIOS-Name Service")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "NetBIOS" in db:
                print(db)
                f.close()
    elif port_test == "138":
        print(f"[{green}+{reset}]Port Open 138 Service NetBIOS-Data")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "NetBIOS" in db:
                print(db)
                f.close()
    elif port_test == "139":
        print(f"[{green}+{reset}]Port Open 138 Service NetBIOS-Conversation")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "NetBIOS" in db:
                print(db)
                f.close()
    elif port_test == "123":
        print(f"[{green}+{reset}]Port Open 123 Service UDP")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "UDP" in db:
                print(db)
                f.close()
    elif port_test == "520":
        print(f"[{green}+{reset}]Port Open 520 Service routing information protocol")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "RIP" in db:
                print(db)
                f.close()
    elif port_test == "161":
        print(f"[{green}+{reset}]Port Open 161 Service SNMP")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "SNMP" in db:
                print(db)
                f.close()
    elif port_test == "162":
        print(f"[{green}+{reset}]Port Open 162 Service Simple Network Management Protocol-Trap")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "SNMP" in db:
                print(db)
                f.close()
    elif port_test == "9988":
        print(f"[{green}+{reset}]Port Open 9988 Service Windows Communication Foundation")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "WCF" in db:
                print(db)
                f.close()
    elif port_test == "5355":
        print(f"[{green}+{reset}]Port Open 5355 Service Local Connection Multicast Name Resolution")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "5355" in db:
                print(db)
                f.close()
    elif port_test == "7":
        print(f"[{green}+{reset}]Port Open 7 Service TCP/UDP")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if r"TCP/UDP" in db:
                print(db)
                f.close()
    elif port_test == "135":
        print(f"[{green}+{reset}]Port Open 135 Service Protocol used to publish Exchange servers for RPC access from external networks")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "RPC" in db:
                print(db)
                f.close()
    elif port_test == "79":
        print(f"[{green}+{reset}]Port Open 79 Service Joint program protocol ")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "JPP" in db:
                print(db)
                f.close()
    elif port_test == "1494":
        print(f"[{green}+{reset}]Port Open 1494 Service Citrix intelligent console architecture protocol")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "1494" in db:
                print(db)
                f.close()
    elif port_test == "1723":
        print(f"[{green}+{reset}]Port Open 1723 Service PPTP VPN")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "VPN" in db:
                print(db)
                f.close()
    elif port_test == "1701":
        print(f"[{green}+{reset}]Port Open 1701 Service L2TP VPN")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "VPN" in db:
                print(db)
                f.close()
    elif port_test == "1433":
        print(f"[{green}+{reset}]Port Open 1433 Service Microsoft SQL")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "SQL" in db:
                print(db)
                f.close()
    elif port_test == "1755":
        print(f"[{green}+{reset}]Port Open 1755 Service MMS")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "MMS" in db:
                print(db)
                f.close()
    elif port_test == "1812":
        print(f"[{green}+{reset}]Port Open 1812 Service RADIUS")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "RADIUS" in db:
                print(db)
                f.close()
    elif port_test == "1813":
        print(f"[{green}+{reset}]Port Open 1813 Service Remote authentication dial-up user service accounting protocol")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "Remote authentication" in db:
                print(db)
                f.close()
    elif port_test == "3389":
        print(f"[{green}+{reset}]Port Open 3389 Service RDP")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "RDP" in db:
                print(db)
                f.close()
    elif port_test == "554":
        print(f"[{green}+{reset}]Port Open 554 Service RTSP")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "RTSP" in db:
                print(db)
                f.close()
    elif port_test == "5060":
        print(f"[{green}+{reset}]Port Open 5060 Service SIP")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "SIP" in db:
                print(db)
                f.close()
    elif port_test == "5061":
        print(f"[{green}+{reset}]Port Open 5061 Service SIPS")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "SIPS" in db:
                print(db)
                f.close()
    elif port_test == "1080":
        print(f"[{green}+{reset}]Port Open 1080 Service SOCKS")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "SOCKS" in db:
                print(db)
                f.close()
    elif port_test == "22":
        print(f"[{green}+{reset}]Port Open 22 Service SSH")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "SSH" in db:
                print(db)
                f.close()
    elif port_test == "3544":
        print(f"[{green}+{reset}]Port Open 3544 Service Teredo")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "Teredo" in db:
                print(db)
                f.close()
    elif port_test == "69":
        print(f"[{green}+{reset}]Port Open 69 Service TFTP")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "TFTP" in db:
                print(db)
                f.close()
    elif port_test == "43":
        print(f"[{green}+{reset}]Port Open 43 Service WhoIs")
        f=open(r'db\csv.txt','r')
        dbs=f.readlines()
        for db in dbs:
            a = db.strip()
            if "WhoIs" in db:
                print(db)
                f.close()
    else:
        print(f"[{blue}*{reset}]Port Unkonw" + str(port_list) + "Service Unknow")
def log():
    global db
    open(r"log/Scan_log.db_log","w")
    o = open(r"log/Scan_log.db_log","a")
    o.write(db)
def clear():
    try:
        os.system("cls")
    except():
        os.system("clear")


def start():
    clear()
    main()
start()

